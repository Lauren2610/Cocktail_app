import 'package:flutter/material.dart';
import 'package:cocktail_flutter/Constants/margin.dart';

const kIngredientTopicStyle =
    TextStyle(fontSize: MARGIN_XLARGE, fontWeight: FontWeight.bold);

// const kLongYellowCardTopicStyle =TextStyle()
