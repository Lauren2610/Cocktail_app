import 'package:flutter/material.dart';

const String kIngredients = 'Ingredients';
const String kCategory = 'Category';
const String kSearch = 'Search';
const String kFavorite = 'Favorite';
