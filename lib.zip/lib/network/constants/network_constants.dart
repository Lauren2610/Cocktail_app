import 'package:flutter/material.dart';

const String BASE_URL = 'http://www.thecocktaildb.com/api/json/v1/1';
